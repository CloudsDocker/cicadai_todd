package com.cozitrip.cicada.forex;

public enum Ccy {
    AUD,
    CNY,
    USD,
    GBP
}
