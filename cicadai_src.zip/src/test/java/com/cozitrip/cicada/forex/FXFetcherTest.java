package com.cozitrip.cicada.forex;

import lombok.val;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.assertj.core.api.Assertions.*;

import java.math.BigDecimal;

public class FXFetcherTest {

    private static FXFetcher fxFetcher;
    @BeforeClass
    public static void setup(){
        fxFetcher = new FXFetcher();
    }

    @Test
    public void getFXRate() {
    }

    @Test
    public void shouldGetRateFromParsedJsonString() {
        //given
        String jsonString="{\n" +
                "    \"success\": true,\n" +
                "    \"timestamp\": 1653220143,\n" +
                "    \"base\": \"AUD\",\n" +
                "    \"date\": \"2022-05-22\",\n" +
                "    \"rates\": {\n" +
                "        \"USD\": 0.703639\n" +
                "    }\n" +
                "}";

        //when
        val actual = fxFetcher.parseJsonToGetRate(jsonString, Ccy.USD);
        val expected= BigDecimal.valueOf(0.703639);

        //then
        assertThat(actual).isEqualByComparingTo(expected);
    }
}