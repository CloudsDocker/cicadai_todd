package com.cozitrip.cicada.service;

import java.util.List;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cozitrip.cicada.dao.UserDao;
import com.cozitrip.cicada.entity.User;

@Service
@Transactional(rollbackOn = Exception.class)
public class UserService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(UserService.class);
	
	@Autowired
	private UserDao userDao;

	public List<User> list() {
		LOGGER.info("Listing all users...");
		return userDao.list();
	}

}
