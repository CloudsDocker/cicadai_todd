package com.cozitrip.cicada.dao;

import com.cozitrip.cicada.entity.FXRate;
import com.cozitrip.cicada.entity.User;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class FxRateDaoImpl extends JpaBaseDao<FXRate> implements FxRateDao {

	@Override
	public List<FXRate> list() {
		LOGGER.info("Retrieving all FXRate...");

		List<FXRate> rates = em.createQuery("from FXRate u", FXRate.class).getResultList();

		LOGGER.info(String.format("Retrieved %s rates...", rates.size()));
		return rates;
	}

}
