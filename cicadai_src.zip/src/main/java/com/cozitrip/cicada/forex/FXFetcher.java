package com.cozitrip.cicada.forex;

import com.cozitrip.cicada.dao.FxRateDao;
import com.cozitrip.cicada.entity.FXRate;
import com.google.gson.JsonParser;
import lombok.val;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.methods.RequestBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.function.Consumer;

@Component
public class FXFetcher {
    private static final Logger LOGGER = LoggerFactory.getLogger(FXFetcher.class);

    @Autowired
    private FxRateDao dao;
    Consumer<? super FXRate> rateLoaderFun=rate-> this.getFXRate(Ccy.valueOf(rate.getBaseCcy()),Ccy.valueOf(rate.getCounterCcy()));

    public BigDecimal getFXRate(Ccy baseCcy, Ccy counterCcy) {

        val URL = "https://api.apilayer.com/fixer/latest?base=AUD&symbols=USD";
        val apiKey = "MdcxamZF74tm8TiiZXSQr51TZZwVlrL5";

        HttpClient client = HttpClients.custom().build();
        HttpUriRequest request = RequestBuilder.get()
                .setUri(URL)
                .setHeader("apikey", apiKey)
                .build();
        try {
            val entity = client.execute(request).getEntity();
            val response = EntityUtils.toString(entity);
            val rate = parseJsonToGetRate(response, counterCcy);
            LOGGER.info("retrieved rate is {}", rate);
            return rate;

        } catch (IOException e) {
            LOGGER.error("Failures in fetching FXRate from remote server", e);
        }
        return BigDecimal.ZERO;
    }

    public BigDecimal parseJsonToGetRate(String response, Ccy counterCcy) {
        val jsonObject = new JsonParser().parse(response).getAsJsonObject();
        val rateObject = jsonObject.getAsJsonObject("rates");
        val rateStr = rateObject.get(counterCcy.name()).getAsString();
        val rateDecimal =new BigDecimal(rateStr);
        LOGGER.info("Parsed rate is:{}",rateDecimal);
        return rateDecimal;
    }

    public void scheduleLoading(){
        LOGGER.info("======Scheduled run====");
        val listRates = dao.list();
        listRates.forEach(rateLoaderFun);
        LOGGER.info("===done of scheduled run===");
    }

}
