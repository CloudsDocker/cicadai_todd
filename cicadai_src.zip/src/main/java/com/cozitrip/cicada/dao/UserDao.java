package com.cozitrip.cicada.dao;

import com.cozitrip.cicada.entity.User;

public interface UserDao extends BaseDao<User> {

}
