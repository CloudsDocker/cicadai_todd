package com.cozitrip.cicada.web.publish.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/support")
public class SupportController {

    @RequestMapping(value = "/healthy", method = RequestMethod.GET)
    @ResponseBody
    public String health(){
return "I'm healthy";
    }
}
