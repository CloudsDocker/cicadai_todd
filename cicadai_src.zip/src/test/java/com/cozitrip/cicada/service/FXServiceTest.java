package com.cozitrip.cicada.service;

import com.cozitrip.cicada.forex.Ccy;
import com.cozitrip.cicada.forex.FXFetcher;
import com.cozitrip.cicada.forex.FXRateForDBHandler;
import lombok.val;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.mockito.*;

import java.math.BigDecimal;

import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.assertj.core.api.Assertions.*;

public class FXServiceTest {

    @Mock
    private FXFetcher fetcher;

    @Spy
    private FXRateForDBHandler handler;

    @InjectMocks
    private static FXService sut;

    @Captor
    ArgumentCaptor<Ccy> baseArg;

    @Captor
    ArgumentCaptor<Ccy> counterArg;

    @Captor
    ArgumentCaptor<BigDecimal> rateArg;

    @Before
    public void setup(){
        MockitoAnnotations.initMocks(this);
        sut=new FXService(fetcher, handler);
    }

    @Test
    public void shouldGetLatestRate() {
        val base = Ccy.AUD;
        val counter = Ccy.USD;
        val expected=BigDecimal.valueOf(1.23);

        // when
        when(fetcher.getFXRate(any(),any())).thenReturn(expected);
//        verify(handler).process(baseArg.capture(), counterArg.capture(),rateArg.capture());

        //then
        val actual = sut.getLatestRate(base, counter);

        assertThat(actual).isEqualByComparingTo(expected);
//        assertThat(baseArg.getValue()).isEqualByComparingTo(base);


    }
}