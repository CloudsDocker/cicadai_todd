package com.cozitrip.cicada.forex;

import java.math.BigDecimal;

public interface CicaHandler {
    void process(Ccy baseCcy, Ccy counterCcy, BigDecimal rate);
}
