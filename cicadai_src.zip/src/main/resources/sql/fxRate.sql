DROP TABLE IF EXISTS `fxRate`;
CREATE TABLE `fxRate` (
  `seqNum`            int NOT NULL AUTO_INCREMENT,
  `ccy`      char(6)  NOT NULL,
  `baseCcy`      char(3)  NOT NULL,
  `counterCcy`      char(3)  NOT NULL,
  `rate` decimal(20,4)    NULL,
  `lastTimeStamp` timestamp    NULL,
    PRIMARY KEY (`seqNum`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
