package com.cozitrip.cicada.web.publish.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cozitrip.cicada.entity.User;
import com.cozitrip.cicada.service.UserService;

@RestController
@RequestMapping({ "/user" })
public class UserController {
	
	final private static Logger LOGGER = LoggerFactory.getLogger(UserController.class);
	
	@Autowired
	private UserService userService;

	
	@RequestMapping("/list")
	public List<User> list() {
		LOGGER.debug("Listing users");
		List<User> users = userService.list();

		LOGGER.debug("Returning listed users");
		return users;
	}

}