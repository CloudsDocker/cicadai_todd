package com.cozitrip.cicada.service;

import com.cozitrip.cicada.forex.Ccy;
import com.cozitrip.cicada.forex.CicaHandler;
import com.cozitrip.cicada.forex.FXFetcher;
import com.cozitrip.cicada.forex.FXRateForDBHandler;
import lombok.RequiredArgsConstructor;
import lombok.val;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import javax.transaction.Transactional;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Service
@Transactional(rollbackOn = Exception.class)
@RequiredArgsConstructor
public class FXService {
    private static final Logger LOGGER = LoggerFactory.getLogger(FXService.class);

    private final FXFetcher fxFetcher;

    List<CicaHandler> listeners=new ArrayList<>();

    private final FXRateForDBHandler dbHandler;

    @PostConstruct
    public void setupListeners() {
        listeners.add(dbHandler);
    }

    public BigDecimal getLatestRate(Ccy baseCcy, Ccy counterCcy){
        val rate= fxFetcher.getFXRate(baseCcy, counterCcy);
        LOGGER.info("invoke all listeners to process returned FX Rate, data are: {}/{} rate is {}", baseCcy, counterCcy, rate);
        LOGGER.info("listeners size is:{}",listeners.size());
        listeners.forEach(it->it.process(baseCcy, counterCcy, rate));
        return rate;
    }
}
