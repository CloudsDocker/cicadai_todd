package com.cozitrip.cicada.forex;

import com.cozitrip.cicada.dao.FxRateDao;
import com.cozitrip.cicada.entity.FXRate;
import lombok.val;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Date;

@Component
public class FXRateForDBHandler implements CicaHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger(FXRateForDBHandler.class);

    @Autowired
    FxRateDao fxRateDao;

    @Override
    public void process(Ccy baseCcy, Ccy counterCcy, BigDecimal rate) {
        LOGGER.info("Going to save to DB for rate:{} on {}/{}", rate, baseCcy, counterCcy);
        try {
            val fxRate = new FXRate();
            fxRate.setBaseCcy(baseCcy.name());
            fxRate.setCcy(baseCcy.name() + counterCcy.name());
            fxRate.setCounterCcy(counterCcy.name());
            fxRate.setLastTimeStamp(new Date());
            fxRateDao.save(fxRate);
        } catch (Exception e) {
            LOGGER.error("Error during save Rate to DB", e);
        }
    }
}
