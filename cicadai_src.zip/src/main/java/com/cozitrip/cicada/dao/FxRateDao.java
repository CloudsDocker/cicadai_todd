package com.cozitrip.cicada.dao;

import com.cozitrip.cicada.entity.FXRate;
import com.cozitrip.cicada.entity.User;

public interface FxRateDao extends BaseDao<FXRate> {

}
