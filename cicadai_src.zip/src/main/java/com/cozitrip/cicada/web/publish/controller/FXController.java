package com.cozitrip.cicada.web.publish.controller;


import com.cozitrip.cicada.forex.Ccy;
import com.cozitrip.cicada.service.FXService;
import lombok.extern.slf4j.Slf4j;
import lombok.val;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;
import java.util.Locale;
import java.util.Objects;

@Slf4j
@RestController
@RequestMapping("/fx")
public class FXController {


    @Autowired
    private FXService fxService;

    @RequestMapping(value = "/latest/{baseCcy}/{counterCcy}", method = RequestMethod.GET)
    public BigDecimal getFXRate(@PathVariable("baseCcy") final String ccy1, @PathVariable("counterCcy") final String ccy2) {

        try {
            Objects.requireNonNull(ccy1);
            Objects.requireNonNull(ccy2);
            val baseCcy = Ccy.valueOf(ccy1.toUpperCase());
            val counterCcy = Ccy.valueOf(ccy2.toUpperCase());
            log.info("going to look up fx rate for base ccy:{} vs counter ccy:{}", ccy1, ccy2);
            return fxService.getLatestRate(baseCcy,counterCcy);

        } catch (Exception e) {
            log.error("Failed to get FX rate for {}/{}", ccy1, ccy2, e);

        }
        return BigDecimal.ZERO;

    }
}
