package com.cozitrip.cicada.entity;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.math.BigDecimal;
import java.util.Date;

@Data
@Entity
@NoArgsConstructor
@Table(name = "fxRate")
public class FXRate {

    @Id
    private int seqNum;

    @Column
    private String ccy;

    @Column
    private String baseCcy;

    @Column
    private String counterCcy;

    @Column
    private BigDecimal rate;

    @Column
    private Date lastTimeStamp;

}
