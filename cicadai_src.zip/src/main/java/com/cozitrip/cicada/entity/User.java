package com.cozitrip.cicada.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "user")
public class User {

	@Id
	protected String uuid;

	@Column(nullable = true)
	private String email;

	@Column(nullable = true)
	private String password;

	@Column(nullable = true)
	private String entityUuid;

	@Column(nullable = true)
	private String bindToUuid;

	@Column(nullable = true)
	private boolean emailVerified;

	@Column(nullable = true)
	@Enumerated(EnumType.STRING)
	private LoginType loginType;

	@Column(nullable = true)
	private String telephone;

	@Column(nullable = true)
	private String contact;

	@Column(nullable = true)
	private String givenname;

	@Column(nullable = true)
	private String surname;

	@Column(nullable = true)
	private String description;

	@Column(nullable = true)
	private String locale;

	@Column(nullable = false)
	private boolean valid;

	@Column(nullable = true)
	private Date invalidDate;

	@Column(nullable = false)
	private boolean locked;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(nullable = true)
	private Date lockedDate;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(nullable = true)
	private Date loginTime;

	@Column(nullable = true)
	@Temporal(TemporalType.TIMESTAMP)
	private Date lastUpdatedTime;

	@Column(nullable = true)
	private String loginIp;

	@Column
	protected String createdBy;

	@Column
	protected String modifiedBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column
	protected Date createdDate = new Date();

	@Temporal(TemporalType.TIMESTAMP)
	@Column
	protected Date modifiedDate = new Date();

	public enum LoginType {

		Email, Gmail, Office365
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getGivenname() {
		return givenname;
	}

	public void setGivenname(String givenname) {
		this.givenname = givenname;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getLocale() {
		return locale;
	}

	public void setLocale(String locale) {
		this.locale = locale;
	}

	public boolean isValid() {
		return valid;
	}

	public void setValid(boolean valid) {
		this.valid = valid;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getTelephone() {
		return telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public boolean isEmailVerified() {
		return emailVerified;
	}

	public void setEmailVerified(boolean emailVerified) {
		this.emailVerified = emailVerified;
	}

	public LoginType getLoginType() {
		return loginType;
	}

	public void setLoginType(LoginType loginType) {
		this.loginType = loginType;
	}

	public Date getInvalidDate() {
		return invalidDate;
	}

	public void setInvalidDate(Date invalidDate) {
		this.invalidDate = invalidDate;
	}

	public boolean isLocked() {
		return locked;
	}

	public void setLocked(boolean locked) {
		this.locked = locked;
	}

	public Date getLockedDate() {
		return lockedDate;
	}

	public void setLockedDate(Date lockedDate) {
		this.lockedDate = lockedDate;
	}

	public String getEntityUuid() {
		return entityUuid;
	}

	public void setEntityUuid(String entityUuid) {
		this.entityUuid = entityUuid;
	}

	public String getBindToUuid() {
		return bindToUuid;
	}

	public void setBindToUuid(String bindToUuid) {
		this.bindToUuid = bindToUuid;
	}

	public Date getLoginTime() {
		return loginTime;
	}

	public void setLoginTime(Date loginTime) {
		this.loginTime = loginTime;
	}

	public Date getLastUpdatedTime() {
		return lastUpdatedTime;
	}

	public void setLastUpdatedTime(Date lastUpdatedTime) {
		this.lastUpdatedTime = lastUpdatedTime;
	}

	public String getLoginIp() {
		return loginIp;
	}

	public void setLoginIp(String loginIp) {
		this.loginIp = loginIp;
	}

	@Override
	public String toString() {
		return "User [email=" + email + ", password=" + password + ", entityUuid=" + entityUuid + ", bindToUuid="
				+ bindToUuid + ", emailVerified=" + emailVerified + ", loginType=" + loginType + ", telephone="
				+ telephone + ", contact=" + contact + ", givenname=" + givenname + ", surname=" + surname
				+ ", description=" + description + ", locale=" + locale + ", valid=" + valid + ", invalidDate="
				+ invalidDate + ", locked=" + locked + ", lockedDate=" + lockedDate + "]";
	}
}
