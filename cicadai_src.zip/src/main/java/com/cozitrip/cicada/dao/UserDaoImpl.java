package com.cozitrip.cicada.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cozitrip.cicada.entity.User;

@Repository
public class UserDaoImpl extends JpaBaseDao<User> implements UserDao {

	@Override
	public List<User> list() {
		LOGGER.info("Retrieving all users...");

		List<User> users = em.createQuery("from User u", User.class).getResultList();

		LOGGER.info(String.format("Retrieved %s users...", users.size()));
		return users;
	}

}
